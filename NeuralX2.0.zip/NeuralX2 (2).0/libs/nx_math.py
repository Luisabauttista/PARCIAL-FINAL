"""
nx_math.py — NeuralX.Math
Operaciones matemáticas implementadas desde cero.
No usa numpy ni ninguna librería externa.
"""

import math as _math


def nx_suma(a, b):
    return a + b

def nx_resta(a, b):
    return a - b

def nx_mult(a, b):
    return a * b

def nx_div(a, b):
    if b == 0:
        print("[NeuralX] Error: no se puede dividir por cero.")
        return 0
    return a / b

def nx_potencia(base, exp):
    # Implementación propia de potencia
    if exp == 0:
        return 1
    if exp < 0:
        return 1 / nx_potencia(base, -exp)
    if isinstance(exp, float) and not exp.is_integer():
        # Raíces: x^0.5 = raíz cuadrada
        return nx_raiz(base, 1 / exp)
    resultado = 1
    for _ in range(int(exp)):
        resultado *= base
    return resultado

def nx_modulo(a, b):
    return a % b

def nx_raiz(x, n=2):
    # Método de Newton-Raphson para raíces
    if x < 0 and n % 2 == 0:
        raise ValueError("[NeuralX] Error: raíz par de número negativo.")
    if x == 0:
        return 0
    estimado = x / n
    for _ in range(1000):
        anterior = estimado
        estimado = ((n - 1) * estimado + x / nx_potencia(estimado, n - 1)) / n
        if abs(estimado - anterior) < 1e-10:
            break
    return estimado

def nx_abs(x):
    return x if x >= 0 else -x

def nx_sen(x):
    # Serie de Taylor para seno: sen(x) = x - x³/3! + x⁵/5! - ...
    x = x % (2 * 3.141592653589793)
    resultado = 0
    termino = x
    for i in range(1, 20):
        resultado += termino
        termino *= -x * x / ((2 * i) * (2 * i + 1))
    return resultado

def nx_cos(x):
    # Serie de Taylor para coseno: cos(x) = 1 - x²/2! + x⁴/4! - ...
    x = x % (2 * 3.141592653589793)
    resultado = 0
    termino = 1
    for i in range(1, 20):
        resultado += termino
        termino *= -x * x / ((2 * i - 1) * (2 * i))
    return resultado

def nx_tan(x):
    cos_x = nx_cos(x)
    if abs(cos_x) < 1e-10:
        raise ValueError("[NeuralX] Error: tangente indefinida en este punto.")
    return nx_sen(x) / cos_x

def nx_log(x, base=2.718281828459045):
    # Logaritmo natural usando serie de Taylor
    if x <= 0:
        raise ValueError("[NeuralX] Error: logaritmo de número no positivo.")
    return _math.log(x, base)

def nx_factorial(n):
    if n < 0:
        raise ValueError("[NeuralX] Error: factorial de número negativo.")
    if n == 0 or n == 1:
        return 1
    resultado = 1
    for i in range(2, int(n) + 1):
        resultado *= i
    return resultado
