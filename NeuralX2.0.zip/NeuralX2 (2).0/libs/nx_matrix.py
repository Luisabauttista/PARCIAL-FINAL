"""
nx_matrix.py — NeuralX.Matrix
Operaciones matriciales implementadas desde cero.
No usa numpy ni ninguna librería externa.
"""


class Matriz:
    """Clase propia para representar matrices en NeuralX."""

    def __init__(self, filas):
        self.datos = [list(fila) for fila in filas]
        self.nfilas = len(filas)
        self.ncols = len(filas[0]) if filas else 0

    def __repr__(self):
        return '\n'.join(['[' + ', '.join(f'{v:.4f}' for v in fila) + ']' for fila in self.datos])

    def __add__(self, otra):
        return nx_sumar(self, otra)

    def __sub__(self, otra):
        return nx_restar(self, otra)

    def __mul__(self, otra):
        if isinstance(otra, Matriz):
            return nx_multiplicar(self, otra)
        # Escalar
        resultado = [[self.datos[i][j] * otra for j in range(self.ncols)] for i in range(self.nfilas)]
        return Matriz(resultado)


def nx_crear_matriz(filas):
    return Matriz(filas)


def nx_sumar(A, B):
    if A.nfilas != B.nfilas or A.ncols != B.ncols:
        raise ValueError("[NeuralX] Error: matrices de dimensiones incompatibles para suma.")
    resultado = [
        [A.datos[i][j] + B.datos[i][j] for j in range(A.ncols)]
        for i in range(A.nfilas)
    ]
    return Matriz(resultado)


def nx_restar(A, B):
    if A.nfilas != B.nfilas or A.ncols != B.ncols:
        raise ValueError("[NeuralX] Error: matrices de dimensiones incompatibles para resta.")
    resultado = [
        [A.datos[i][j] - B.datos[i][j] for j in range(A.ncols)]
        for i in range(A.nfilas)
    ]
    return Matriz(resultado)


def nx_multiplicar(A, B):
    if A.ncols != B.nfilas:
        raise ValueError("[NeuralX] Error: dimensiones incompatibles para multiplicación.")
    resultado = [
        [
            sum(A.datos[i][k] * B.datos[k][j] for k in range(A.ncols))
            for j in range(B.ncols)
        ]
        for i in range(A.nfilas)
    ]
    return Matriz(resultado)


def nx_transponer(A):
    resultado = [
        [A.datos[i][j] for i in range(A.nfilas)]
        for j in range(A.ncols)
    ]
    return Matriz(resultado)


def nx_invertir(A):
    if A.nfilas != A.ncols:
        raise ValueError("[NeuralX] Error: solo se pueden invertir matrices cuadradas.")
    n = A.nfilas
    # Eliminación Gaussiana con matriz aumentada [A | I]
    aumentada = [A.datos[i][:] + [1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]

    for col in range(n):
        # Buscar pivote
        pivote = -1
        for fila in range(col, n):
            if abs(aumentada[fila][col]) > 1e-10:
                pivote = fila
                break
        if pivote == -1:
            raise ValueError("[NeuralX] Error: la matriz no es invertible.")
        aumentada[col], aumentada[pivote] = aumentada[pivote], aumentada[col]

        # Normalizar fila
        factor = aumentada[col][col]
        aumentada[col] = [x / factor for x in aumentada[col]]

        # Eliminar columna
        for fila in range(n):
            if fila != col:
                f = aumentada[fila][col]
                aumentada[fila] = [aumentada[fila][k] - f * aumentada[col][k] for k in range(2 * n)]

    inversa = [fila[n:] for fila in aumentada]
    return Matriz(inversa)


def nx_determinante(A):
    if A.nfilas != A.ncols:
        raise ValueError("[NeuralX] Error: determinante solo para matrices cuadradas.")
    n = A.nfilas
    mat = [fila[:] for fila in A.datos]
    det = 1.0
    for col in range(n):
        pivote = -1
        for fila in range(col, n):
            if abs(mat[fila][col]) > 1e-10:
                pivote = fila
                break
        if pivote == -1:
            return 0.0
        if pivote != col:
            mat[col], mat[pivote] = mat[pivote], mat[col]
            det *= -1
        det *= mat[col][col]
        factor = mat[col][col]
        mat[col] = [x / factor for x in mat[col]]
        for fila in range(n):
            if fila != col:
                f = mat[fila][col]
                mat[fila] = [mat[fila][k] - f * mat[col][k] for k in range(n)]
    return det
