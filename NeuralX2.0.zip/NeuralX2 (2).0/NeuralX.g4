grammar NeuralX;

// ─────────────────────────────────────────────
//  REGLA DE INICIO
// ─────────────────────────────────────────────

prog: instruccion+ EOF ;

// ─────────────────────────────────────────────
//  INSTRUCCIONES
// ─────────────────────────────────────────────

instruccion
    : declaracionVar
    | declaracionFuncion
    | retorno
    | instruccionML
    | instruccionMatrix
    | instruccionPlot
    | instruccionRed
    | instruccionIO
    | importacion
    | condicional
    | cicloFor
    | cicloWhile
    | expresion
    ;

// ─────────────────────────────────────────────
//  VARIABLES
// ─────────────────────────────────────────────

declaracionVar
    : VAR IDENTIFICADOR ASIGNACION expresion ;

// ─────────────────────────────────────────────
//  FUNCIONES Y RECURSIVIDAD
// ─────────────────────────────────────────────

declaracionFuncion
    : FUNCION IDENTIFICADOR '(' parametros? ')' '{' instruccion+ '}' ;

parametros
    : IDENTIFICADOR (',' IDENTIFICADOR)* ;

llamadaFuncion
    : IDENTIFICADOR '(' argumentos? ')' ;

argumentos
    : expresion (',' expresion)* ;

retorno
    : RETORNAR expresion ;

// ─────────────────────────────────────────────
//  IMPORTACIONES
// ─────────────────────────────────────────────

importacion
    : IMPORT modulo ;

modulo
    : 'NeuralX.Math'
    | 'NeuralX.Matrix'
    | 'NeuralX.Plot'
    | 'NeuralX.ML'
    | 'NeuralX.Net'
    | 'NeuralX.IO'
    ;

// ─────────────────────────────────────────────
//  EXPRESIONES CON PRECEDENCIA
// ─────────────────────────────────────────────

expresion
    : expresion POTENCIA expresion                          #Potencia
    | expresion MULT expresion                              #Multiplicacion
    | expresion DIV expresion                               #Division
    | expresion SUMA expresion                              #Suma
    | expresion RESTA expresion                             #Resta
    | expresion MODULO expresion                            #ModuloOp
    | SEN '(' expresion ')'                                 #Seno
    | COS '(' expresion ')'                                 #Coseno
    | TAN '(' expresion ')'                                 #Tangente
    | '(' expresion ')'                                     #Parentesis
    | TRANSPONER '(' expresion ')'                          #TransponerExpr
    | INVERTIR '(' expresion ')'                            #InvertirExpr
    | AJUSTAR '(' expresion ',' expresion ')'               #AjustarExpr
    | CLASIFICAR '(' expresion ',' expresion ')'            #ClasificarExpr
    | PREDECIR '(' expresion ',' expresion ')'              #PredecirExpr
    | COEFICIENTES '(' expresion ')'                        #CoeficientesExpr
    | llamadaFuncion                                        #LlamadaExpr
    | NUMERO                                                #Numero
    | CADENA                                                #CadenaExpr
    | VERDADERO                                             #Verdadero
    | FALSO                                                 #Falso
    | IDENTIFICADOR                                         #Variable
    | lista                                                 #ListaExpr
    | declaracionMatriz                                     #MatrizExpr
    ;

// ─────────────────────────────────────────────
//  LISTAS Y MATRICES
// ─────────────────────────────────────────────

lista : '[' (expresion (',' expresion)*)? ']' ;

declaracionMatriz
    : MAT '[' '[' listaNumeros ']' (',' '[' listaNumeros ']')* ']' ;

listaNumeros
    : NUMERO (',' NUMERO)* ;

// ─────────────────────────────────────────────
//  CONDICIONALES
// ─────────────────────────────────────────────

condicional
    : SI '(' condicion ')' '{' instruccion+ '}'
      (SINO SI '(' condicion ')' '{' instruccion+ '}')*
      (SINO '{' instruccion+ '}')? ;

condicion
    : expresion MAYOR expresion                             #CondMayor
    | expresion MENOR expresion                             #CondMenor
    | expresion IGUAL expresion                             #CondIgual
    | expresion DIFERENTE expresion                         #CondDiferente
    | expresion MAYORIGUAL expresion                        #CondMayorIgual
    | expresion MENORIGUAL expresion                        #CondMenorIgual
    | condicion Y condicion                                 #CondY
    | condicion O condicion                                 #CondO
    | NO condicion                                          #CondNo
    ;

// ─────────────────────────────────────────────
//  CICLOS
// ─────────────────────────────────────────────

cicloFor
    : REPITE IDENTIFICADOR EN '[' NUMERO '..' NUMERO ']' '{' instruccion+ '}' ;

cicloWhile
    : MIENTRAS '(' condicion ')' '{' instruccion+ '}' ;

// ─────────────────────────────────────────────
//  MODULOS
// ─────────────────────────────────────────────

instruccionML
    : AJUSTAR '(' expresion ',' expresion ')'
    | CLASIFICAR '(' expresion ',' expresion ')'
    | PREDECIR '(' expresion ',' expresion ')'
    | COEFICIENTES '(' expresion ')'
    ;

instruccionMatrix
    : TRANSPONER '(' expresion ')'
    | INVERTIR '(' expresion ')'
    ;

instruccionPlot
    : GRAFICAR '(' expresion ',' expresion ')'
    | DISPERSAR '(' expresion ',' expresion ')'
    | TITULO '(' CADENA ')'
    | EJEX '(' CADENA ')'
    | EJEY '(' CADENA ')'
    | MOSTRAR '(' ')'
    ;

instruccionRed
    : RED '(' CAPAS '=' '[' listaNumeros ']' ')'
    | PERCEPTRON '(' CAPAS '=' '[' listaNumeros ']' ')'
    | ENTRENAR '(' expresion ',' expresion ',' expresion ')'
    ;

instruccionIO
    : ABRIR '(' CADENA ')'
    | GUARDAR '(' CADENA ',' expresion ')'
    | MOSTRAR '(' expresion ')'
    ;

// ─────────────────────────────────────────────
//  TOKENS — KEYWORDS
// ─────────────────────────────────────────────

VAR          : 'var' ;
IMPORT       : 'import' ;
FUNCION      : 'funcion' ;
RETORNAR     : 'retornar' ;
SI           : 'si' ;
SINO         : 'sino' ;
REPITE       : 'repite' ;
EN           : 'en' ;
MIENTRAS     : 'mientras' ;
VERDADERO    : 'verdadero' ;
FALSO        : 'falso' ;
Y            : 'y' ;
O            : 'o' ;
NO           : 'no' ;
MAT          : 'mat' ;
TRANSPONER   : 'transponer' ;
INVERTIR     : 'invertir' ;
AJUSTAR      : 'ajustar' ;
CLASIFICAR   : 'clasificar' ;
PREDECIR     : 'predecir' ;
COEFICIENTES : 'coeficientes' ;
GRAFICAR     : 'graficar' ;
DISPERSAR    : 'dispersar' ;
TITULO       : 'titulo' ;
EJEX         : 'ejeX' ;
EJEY         : 'ejeY' ;
MOSTRAR      : 'mostrar' ;
RED          : 'red' ;
PERCEPTRON   : 'perceptron' ;
ENTRENAR     : 'entrenar' ;
CAPAS        : 'capas' ;
ABRIR        : 'abrir' ;
GUARDAR      : 'guardar' ;
SEN          : 'sen' ;
COS          : 'cos' ;
TAN          : 'tan' ;

// ─────────────────────────────────────────────
//  TOKENS — OPERADORES
// ─────────────────────────────────────────────

SUMA         : '+' ;
RESTA        : '-' ;
MULT         : '*' ;
DIV          : '/' ;
POTENCIA     : '^' ;
MODULO       : 'mod' ;
ASIGNACION   : '=' ;
MAYOR        : '>' ;
MENOR        : '<' ;
IGUAL        : '==' ;
DIFERENTE    : '!=' ;
MAYORIGUAL   : '>=' ;
MENORIGUAL   : '<=' ;

// ─────────────────────────────────────────────
//  TOKENS — LITERALES
// ─────────────────────────────────────────────

NUMERO        : [0-9]+ ('.' [0-9]+)? ;
CADENA        : '"' (~'"')* '"' ;
IDENTIFICADOR : [a-zA-Z_][a-zA-Z0-9_]* ;
WS            : [ \t\r\n]+ -> skip ;
COMENTARIO    : '//' ~[\r\n]* -> skip ;
