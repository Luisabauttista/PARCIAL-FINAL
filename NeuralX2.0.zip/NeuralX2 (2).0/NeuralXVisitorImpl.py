"""
NeuralXVisitorImpl.py
Visitor de NeuralX — usa librerías propias del equipo.
"""

# ─────────────────────────────────────────────
#  LIBRERÍAS PROPIAS DE NEURALX
# ─────────────────────────────────────────────
from libs.nx_math import (
    nx_suma, nx_resta, nx_mult, nx_div, nx_potencia,
    nx_modulo, nx_sen, nx_cos, nx_tan, nx_raiz, nx_abs
)
from libs.nx_matrix import (
    nx_crear_matriz, nx_sumar, nx_restar,
    nx_multiplicar, nx_transponer, nx_invertir, Matriz
)
# tensorflow es opcional — solo para red neuronal
try:
    from tensorflow import keras
    KERAS_OK = True
except ImportError:
    KERAS_OK = False

from NeuralXVisitor import NeuralXVisitor


class NeuralXVisitorImpl(NeuralXVisitor):

    def __init__(self):
        self.tabla = {}        # variables
        self.funciones = {}    # funciones declaradas
        self._retorno = None
        self._hay_retorno = False

    # ─────────────────────────────────────────────
    #  VARIABLES
    # ─────────────────────────────────────────────

    def visitDeclaracionVar(self, ctx):
        nombre = ctx.IDENTIFICADOR().getText()
        valor = self.visit(ctx.expresion())
        self.tabla[nombre] = valor
        return valor

    def visitVariable(self, ctx):
        nombre = ctx.IDENTIFICADOR().getText()
        if nombre not in self.tabla:
            raise NameError(f"[NeuralX] Error: variable '{nombre}' no fue declarada.")
        return self.tabla[nombre]

    # ─────────────────────────────────────────────
    #  FUNCIONES Y RECURSIVIDAD
    # ─────────────────────────────────────────────

    def visitDeclaracionFuncion(self, ctx):
        nombre = ctx.IDENTIFICADOR().getText()
        self.funciones[nombre] = ctx
        return None

    def visitRetorno(self, ctx):
        valor = self.visit(ctx.expresion())
        self._retorno = valor
        self._hay_retorno = True
        return valor

    def visitLlamadaExpr(self, ctx):
        return self.visit(ctx.llamadaFuncion())

    def visitLlamadaFuncion(self, ctx):
        nombre = ctx.IDENTIFICADOR().getText()
        if nombre not in self.funciones:
            raise NameError(f"[NeuralX] Error: función '{nombre}' no fue declarada.")

        func_ctx = self.funciones[nombre]
        args = []
        if ctx.argumentos():
            args = [self.visit(e) for e in ctx.argumentos().expresion()]

        params = []
        if func_ctx.parametros():
            params = [p.getText() for p in func_ctx.parametros().IDENTIFICADOR()]

        if len(args) != len(params):
            raise TypeError(f"[NeuralX] Error: '{nombre}' espera {len(params)} argumento(s), recibió {len(args)}.")

        tabla_anterior = self.tabla.copy()
        for param, arg in zip(params, args):
            self.tabla[param] = arg

        self._hay_retorno = False
        self._retorno = None
        for instr in func_ctx.instruccion():
            self.visit(instr)
            if self._hay_retorno:
                break

        resultado = self._retorno
        self._hay_retorno = False
        self._retorno = None
        self.tabla = tabla_anterior
        return resultado

    # ─────────────────────────────────────────────
    #  ARITMÉTICA — usa nx_math.py
    # ─────────────────────────────────────────────

    def visitSuma(self, ctx):
        return nx_suma(self.visit(ctx.expresion(0)), self.visit(ctx.expresion(1)))

    def visitResta(self, ctx):
        return nx_resta(self.visit(ctx.expresion(0)), self.visit(ctx.expresion(1)))

    def visitMultiplicacion(self, ctx):
        izq = self.visit(ctx.expresion(0))
        der = self.visit(ctx.expresion(1))
        if isinstance(izq, Matriz) and isinstance(der, Matriz):
            return nx_multiplicar(izq, der)
        return nx_mult(izq, der)

    def visitDivision(self, ctx):
        return nx_div(self.visit(ctx.expresion(0)), self.visit(ctx.expresion(1)))

    def visitPotencia(self, ctx):
        return nx_potencia(self.visit(ctx.expresion(0)), self.visit(ctx.expresion(1)))

    def visitModuloOp(self, ctx):
        return nx_modulo(self.visit(ctx.expresion(0)), self.visit(ctx.expresion(1)))

    def visitSeno(self, ctx):
        return nx_sen(self.visit(ctx.expresion()))

    def visitCoseno(self, ctx):
        return nx_cos(self.visit(ctx.expresion()))

    def visitTangente(self, ctx):
        return nx_tan(self.visit(ctx.expresion()))

    def visitNumero(self, ctx):
        return float(ctx.NUMERO().getText())

    def visitCadenaExpr(self, ctx):
        return ctx.CADENA().getText().strip('"')

    def visitVerdadero(self, ctx):
        return True

    def visitFalso(self, ctx):
        return False

    def visitParentesis(self, ctx):
        return self.visit(ctx.expresion())

    # ─────────────────────────────────────────────
    #  LISTAS Y MATRICES — usa nx_matrix.py
    # ─────────────────────────────────────────────

    def visitListaExpr(self, ctx):
        return [self.visit(e) for e in ctx.lista().expresion()]

    def visitMatrizExpr(self, ctx):
        filas = []
        for listaCtx in ctx.declaracionMatriz().listaNumeros():
            fila = [float(n.getText()) for n in listaCtx.NUMERO()]
            filas.append(fila)
        return nx_crear_matriz(filas)

    def visitTransponerExpr(self, ctx):
        return nx_transponer(self.visit(ctx.expresion()))

    def visitInvertirExpr(self, ctx):
        return nx_invertir(self.visit(ctx.expresion()))

    def visitInstruccionMatrix(self, ctx):
        if ctx.TRANSPONER():
            return nx_transponer(self.visit(ctx.expresion()))
        elif ctx.INVERTIR():
            return nx_invertir(self.visit(ctx.expresion()))

    # ─────────────────────────────────────────────
    #  REDES NEURONALES
    # ─────────────────────────────────────────────

    def visitInstruccionRed(self, ctx):
        capas = [int(n.getText()) for n in ctx.listaNumeros().NUMERO()]
        if ctx.RED():
            if not KERAS_OK:
                raise ImportError("[NeuralX] Error: tensorflow no instalado.")
            modelo = keras.Sequential()
            for c in capas[:-1]:
                modelo.add(keras.layers.Dense(c, activation='relu'))
            modelo.add(keras.layers.Dense(capas[-1]))
            modelo.compile(optimizer='adam', loss='mse')
            print(f"[NeuralX] Red neuronal creada con capas: {capas}")
            return modelo
        elif ctx.PERCEPTRON():
            from libs.nx_ml import RegresionLogistica
            print(f"[NeuralX] Perceptrón creado: {capas}")
            return RegresionLogistica()
        elif ctx.ENTRENAR():
            modelo = self.visit(ctx.expresion(0))
            x = self.visit(ctx.expresion(1))
            y = self.visit(ctx.expresion(2))
            modelo.ajustar(x, y)
            print("[NeuralX] Entrenamiento completado.")
            return modelo

    # ─────────────────────────────────────────────
    #  IO
    # ─────────────────────────────────────────────

    def visitInstruccionIO(self, ctx):
        if ctx.ABRIR():
            ruta = ctx.CADENA().getText().strip('"')
            try:
                with open(ruta, 'r', encoding='utf-8') as f:
                    contenido = f.read()
                print(f"[NeuralX] Archivo '{ruta}' leído correctamente.")
                return contenido
            except FileNotFoundError:
                raise FileNotFoundError(f"[NeuralX] Error: archivo '{ruta}' no encontrado.")
        elif ctx.GUARDAR():
            ruta = ctx.CADENA().getText().strip('"')
            datos = str(self.visit(ctx.expresion()))
            with open(ruta, 'w', encoding='utf-8') as f:
                f.write(datos)
            print(f"[NeuralX] Datos guardados en '{ruta}'.")
        elif ctx.MOSTRAR():
            valor = self.visit(ctx.expresion())
            print(valor)
            return valor

    # ─────────────────────────────────────────────
    #  CONDICIONALES
    # ─────────────────────────────────────────────

    def visitCondicional(self, ctx):
        condiciones = ctx.condicion()
        instrucciones = ctx.instruccion()
        llaves = []
        for i in range(ctx.getChildCount()):
            hijo = ctx.getChild(i)
            if hasattr(hijo, 'symbol') and hijo.symbol.text == '{':
                llaves.append(hijo.symbol.tokenIndex)

        n_bloques = len(llaves)
        bloques = [[] for _ in range(n_bloques)]
        for instr in instrucciones:
            pos = instr.start.tokenIndex
            bloque_asignado = 0
            for j, llave_pos in enumerate(llaves):
                if pos > llave_pos:
                    bloque_asignado = j
            bloques[bloque_asignado].append(instr)

        n_si = len(condiciones)
        for i, condicion in enumerate(condiciones):
            if self.visit(condicion):
                for instr in bloques[i]:
                    self.visit(instr)
                    if self._hay_retorno:
                        return
                return

        if n_bloques > n_si:
            for instr in bloques[n_si]:
                self.visit(instr)
                if self._hay_retorno:
                    return

    def visitCondMayor(self, ctx):
        return self.visit(ctx.expresion(0)) > self.visit(ctx.expresion(1))

    def visitCondMenor(self, ctx):
        return self.visit(ctx.expresion(0)) < self.visit(ctx.expresion(1))

    def visitCondIgual(self, ctx):
        return self.visit(ctx.expresion(0)) == self.visit(ctx.expresion(1))

    def visitCondDiferente(self, ctx):
        return self.visit(ctx.expresion(0)) != self.visit(ctx.expresion(1))

    def visitCondMayorIgual(self, ctx):
        return self.visit(ctx.expresion(0)) >= self.visit(ctx.expresion(1))

    def visitCondMenorIgual(self, ctx):
        return self.visit(ctx.expresion(0)) <= self.visit(ctx.expresion(1))

    def visitCondY(self, ctx):
        return self.visit(ctx.condicion(0)) and self.visit(ctx.condicion(1))

    def visitCondO(self, ctx):
        return self.visit(ctx.condicion(0)) or self.visit(ctx.condicion(1))

    def visitCondNo(self, ctx):
        return not self.visit(ctx.condicion())

    # ─────────────────────────────────────────────
    #  CICLOS
    # ─────────────────────────────────────────────

    def visitCicloFor(self, ctx):
        variable = ctx.IDENTIFICADOR().getText()
        inicio = int(ctx.NUMERO(0).getText())
        fin = int(ctx.NUMERO(1).getText())
        for i in range(inicio, fin + 1):
            self.tabla[variable] = float(i)
            for instr in ctx.instruccion():
                self.visit(instr)
                if self._hay_retorno:
                    return

    def visitCicloWhile(self, ctx):
        while self.visit(ctx.condicion()):
            for instr in ctx.instruccion():
                self.visit(instr)
                if self._hay_retorno:
                    return

    # ─────────────────────────────────────────────
    #  IMPORTACIONES
    # ─────────────────────────────────────────────

    def visitImportacion(self, ctx):
        modulo = ctx.modulo().getText()
        print(f"[NeuralX] Módulo importado: {modulo}")
